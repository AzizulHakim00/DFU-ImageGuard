# DFU-ImageGuard Model Card

## Intended use
Retrospective research on binary classification of explicitly labelled DFU versus normal image patches. It is not a clinical device and is not deployment-ready.

## Evaluation design
Nested, stratified, duplicate-group-aware five-fold out-of-fold evaluation. The outer test fold is isolated from augmentation, early stopping, temperature scaling and threshold selection. The primary model has one saved checkpoint per outer fold.

## Dataset limitation
The public dataset does not provide patient identifiers. Therefore, this project does **not** claim patient-level splitting. Exact and near-duplicate groups are kept within a fold. The Kaggle data card does not declare a license; redistribution and downstream use must be checked by the researcher.

## Primary calibrated OOF summary
```json
{
  "model": "DFU-ImageGuard",
  "state": "calibrated",
  "fold_thresholds": "{\"0\": 0.9951655134150479, \"1\": 0.9609451133127962, \"2\": 0.9890651480595531, \"3\": 0.9870797337254978, \"4\": 0.9926830043041504}",
  "threshold": NaN,
  "accuracy": 0.9744075829383886,
  "error_rate": 0.025592417061611417,
  "balanced_accuracy": 0.9738000690607735,
  "precision_ppv": 0.9938900203665988,
  "recall_sensitivity": 0.953125,
  "specificity": 0.994475138121547,
  "npv": 0.9574468085106383,
  "f1": 0.9730807577268196,
  "f2": 0.9610082709728239,
  "mcc": 0.9494666452509979,
  "cohen_kappa": 0.9487108849600544,
  "roc_auc": 0.9928673169889503,
  "pr_auc": 0.9909899224135796,
  "log_loss": 0.13683663898839687,
  "brier_score": 0.03468058119223164,
  "ece": 0.047599484373979956,
  "mce": 0.9107220919881817,
  "calibration_slope": 1.2060135034249604,
  "calibration_intercept": -2.582939837618561,
  "fpr": 0.0055248618784530384,
  "fnr": 0.046875,
  "tp": 488,
  "tn": 540,
  "fp": 3,
  "fn": 24
}
```

## Safety
Predictions and XAI maps must not be interpreted as causality, diagnosis, lesion localization proof or clinical correctness. External validation is not claimed unless a scientifically compatible independent dataset is explicitly supplied and evaluated with frozen weights, preprocessing, calibration and threshold.
