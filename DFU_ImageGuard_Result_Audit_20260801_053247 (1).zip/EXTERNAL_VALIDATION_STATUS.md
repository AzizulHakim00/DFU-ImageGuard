# External Validation Status

A genuine external validation experiment was not run because no scientifically compatible independent dataset with a matching binary DFU-versus-normal task was supplied to this run. The pipeline does not relabel a random internal holdout as external data. Future external evaluation must use frozen preprocessing, weights, fold ensemble/calibrators, and the development-selected threshold, with an independent overlap audit before inference.
