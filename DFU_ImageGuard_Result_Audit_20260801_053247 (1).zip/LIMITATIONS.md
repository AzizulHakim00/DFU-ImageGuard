# Limitations

- Patient/case identifiers are unavailable, so patient-level separation cannot be verified.
- Duplicate-group splitting reduces identifiable leakage but cannot guarantee that all source-image derivatives are detected.
- The selected public Kaggle dataset has no declared license on its data card.
- The task uses curated image patches and may not represent full-foot photographs or clinical acquisition workflows.
- Internal five-fold OOF performance is not external validation.
- Fold variation is not multi-seed stability. Genuine multi-seed analysis requires additional training.
- Calibration and threshold selection are development-only procedures and may shift under domain change.
- XAI visualizations are post-hoc explanations and do not prove causality or clinical correctness.
- No sensitive attributes, hospitals, patient variables or modalities are inferred or fabricated.
- Storage mode for this run: `local_fallback`. A local fallback is not persistent after the runtime ends unless exported.
- This retrospective research pipeline is not a medical device and is not clinically deployment-ready.
